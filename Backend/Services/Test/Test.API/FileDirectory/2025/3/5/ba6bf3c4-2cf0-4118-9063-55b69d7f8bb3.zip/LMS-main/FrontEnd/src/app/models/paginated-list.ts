
export interface PaginatedList {
    items:any[]|undefined;
    totalItems:number|undefined;
}


/*
 {
  "items": [],
  "totalItems": 0
}
 */