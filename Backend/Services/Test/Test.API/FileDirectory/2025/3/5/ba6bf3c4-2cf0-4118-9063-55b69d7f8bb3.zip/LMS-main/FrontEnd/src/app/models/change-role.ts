export interface ChangeRole {
        accountStatus:boolean|undefined
        role: string|undefined;
        userId: string|undefined;
}
