﻿using Microsoft.AspNetCore.Identity;

namespace LearnSystem.Models
{
    public class ApplicationRole : IdentityRole<Guid>
    {
    }
}
