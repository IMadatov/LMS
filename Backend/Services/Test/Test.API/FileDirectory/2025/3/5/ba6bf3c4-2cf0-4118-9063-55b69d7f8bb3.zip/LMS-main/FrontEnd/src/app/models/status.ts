export interface Status {
    id: string;
    isOnTelegramBotActive: boolean;
    isActiveAccount: boolean;
    hasPhotoProfile: boolean;
}
