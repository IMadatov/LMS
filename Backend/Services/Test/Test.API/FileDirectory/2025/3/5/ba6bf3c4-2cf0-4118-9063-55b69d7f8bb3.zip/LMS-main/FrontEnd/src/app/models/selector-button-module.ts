export interface SelectorButtonModule {
    name:string;
    code:string;
}
