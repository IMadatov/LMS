import { Component } from '@angular/core';

@Component({
  selector: 'app-tests',
  standalone: true,
  imports: [],
  templateUrl: './tests.component.html',
  styleUrl: './tests.component.css'
})
export class TestsComponent {

}
