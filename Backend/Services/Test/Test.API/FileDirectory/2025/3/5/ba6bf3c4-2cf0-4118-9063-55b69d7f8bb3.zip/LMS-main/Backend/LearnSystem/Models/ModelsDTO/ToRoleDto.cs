﻿namespace LearnSystem.Models.ModelsDTO
{
    public class ToRoleDto
    {
        public string UserId {  get; set; }
        public string Role { get; set; }
    }
}
