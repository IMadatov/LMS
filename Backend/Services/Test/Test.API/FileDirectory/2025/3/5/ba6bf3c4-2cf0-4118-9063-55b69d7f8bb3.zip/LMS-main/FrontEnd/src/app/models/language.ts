export interface Language{
    language: string
  }