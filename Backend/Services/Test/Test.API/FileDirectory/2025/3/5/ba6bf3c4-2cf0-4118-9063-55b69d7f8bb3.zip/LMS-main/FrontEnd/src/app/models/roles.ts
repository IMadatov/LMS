export enum Roles {
    Admin,
    Teacher,
    Student
}
