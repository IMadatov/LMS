export interface Login {
    username:string|undefined|null;
    password:string|undefined|null;
    rememberMe:boolean|undefined|null;
    // {
    //     "username": "IMadatov",
    //     "password": "Qwerty!23",
    //     "rememberMe": true
    //   }
}
