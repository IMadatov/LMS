export interface Signup {
    username:string|undefined|null;
    email:string|undefined|null;
    password:string|undefined|null;
    rememberme:boolean|undefined|null;
}
