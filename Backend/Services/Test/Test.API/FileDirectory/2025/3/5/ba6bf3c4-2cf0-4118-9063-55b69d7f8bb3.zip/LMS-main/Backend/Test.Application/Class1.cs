﻿namespace Test.Application
{
    public class Class1
    {

    }
}
