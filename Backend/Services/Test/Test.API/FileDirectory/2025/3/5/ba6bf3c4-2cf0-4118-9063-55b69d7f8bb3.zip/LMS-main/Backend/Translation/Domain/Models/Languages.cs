﻿namespace Domain.Models;
public enum Languages
{
    ENGLISH,
    UZBEK,
    RUSSIAN,
    KARAKALPAK
}
