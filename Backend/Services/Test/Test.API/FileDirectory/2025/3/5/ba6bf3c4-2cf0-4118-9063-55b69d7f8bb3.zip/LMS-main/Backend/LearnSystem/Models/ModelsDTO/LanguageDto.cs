﻿namespace LearnSystem.Models.ModelsDTO
{
    public class LanguageDto
    {
        public string Language { get; set; }
    }
}
