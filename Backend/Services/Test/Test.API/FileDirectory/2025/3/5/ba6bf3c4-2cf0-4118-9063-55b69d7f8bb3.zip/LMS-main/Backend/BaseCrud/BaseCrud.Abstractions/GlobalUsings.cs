// Global using directives

global using System.Linq.Expressions;
global using BaseCrud.Abstractions.Entities;
global using BaseCrud.Entities;