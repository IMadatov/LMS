﻿namespace BaseCrud.Errors.Keys;

public static partial class ErrorKeys;