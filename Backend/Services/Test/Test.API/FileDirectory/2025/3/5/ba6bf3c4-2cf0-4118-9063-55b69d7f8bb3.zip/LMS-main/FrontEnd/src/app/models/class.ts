import { User } from "./user";

export interface Class{
    id:number;
    name: string;
    dagree:number;
    index:number;
    creator:string;
    createdBy:string;
    createdDate:Date;
}