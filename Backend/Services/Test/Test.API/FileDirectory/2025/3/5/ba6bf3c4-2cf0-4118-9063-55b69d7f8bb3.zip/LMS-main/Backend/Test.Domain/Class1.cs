﻿namespace Test.Domain
{
    public class Class1
    {

    }
}
